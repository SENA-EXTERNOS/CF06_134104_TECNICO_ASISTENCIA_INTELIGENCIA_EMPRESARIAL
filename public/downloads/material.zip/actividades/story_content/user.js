function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jveYNPA6VE":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

