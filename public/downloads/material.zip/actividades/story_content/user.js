function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZC9xj2RfNs":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

